from flask import Flask, render_template, session, request, redirect

app = Flask(__name__)
app.secret_key = 'keep it secret, keep it safe'

@app.route('/')
def surveyDojo():
    return render_template('index.html')

@app.route('/survey', methods=["POST"])
def result():
    print("Got Post Info")
    print(request.form)
    session['name'] = request.form['name']
    session['DojoLocation'] = request.form['DojoLocation']
    session['lang'] = request.form['lang']
    session['com'] = request.form['com']
    return redirect('/display')

@app.route('/display')
def display():
    print(request.form)
    return render_template('display.html')

if __name__=="__main__":
    app.run(debug=True)