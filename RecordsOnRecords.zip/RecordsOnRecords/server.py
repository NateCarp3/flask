from flask import Flask, render_template, request, session, redirect
app = Flask(__name__)
app.secret_key = 'I love Pizza'

@app.route('/')
def index():
    if "album_list" not in session:
        session["album_list"] = []
        
    return render_template('index.html')

@app.route('/process', methods=['POST'])
def formInfo():
    # ImmutableMultiDict([('artist_name', 'Igor Stravinsky'), ('genre', 'Early era'), ('album', 'Firebird'), ('quantity', '3')])

    session["artist_name"] = request.form["artist_name"]
    session["genre"] = request.form["genre"]
    session["album"] = request.form["album"]
    session["quantity"] = request.form["quantity"]
    session['album_list'].append(request.form["album"])

    return redirect('/success')

@app.route('/success')
def success():
    print(session['album_list'])
    return render_template('success.html')

@app.route('/reset')
def reset():
    session.clear()
    return redirect('/')


if __name__ =='__main__':
    app.run(debug=True)