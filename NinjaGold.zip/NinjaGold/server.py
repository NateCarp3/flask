from flask import Flask, render_template, redirect, session, request
import random

app = Flask(__name__)
app.secret_key = 'I love you'
@app.route('/')
def Gold():
    if 'gold_total' not in session:
        session['gold_total'] = 0
    return render_template('index.html')

@app.route('/process_money', methods = ["POST"])
def money():
    session['Farm'] = (random.randint(10,20))
    session['Cave'] = (random.randint(5,10))
    session['House'] = (random.randint(2,5))
    session['Casino'] = (random.randint(-50,50))
    if request.form['building'] == 'Farm':
        session['gold_total'] += session['Farm']
    if request.form['building'] == 'Cave':
        session['gold_total'] += session['Cave']
    if request.form['building'] == 'House':
        session['gold_total'] += session['House']
    if request.form['building'] == 'Casino':
        session['gold_total'] += session['Casino']
    return redirect('/')
if __name__=="__main__":
    app.run(debug=True)