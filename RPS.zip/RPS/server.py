from flask import Flask, render_template, redirect, session, request
import random

app = Flask(__name__)
app.secret_key = "I love Pizza"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process', methods=['POST'])
def process():
    options = ["foot", "nuke", "cockroach"]
    comp_choice = (random.randint(0,2))
    session['comp_choice'] = options[comp_choice]
    session['your_choice'] = request.form['selected']
    if session['comp_choice'] == 'nuke' and request.form['selected'] == 'nuke':
        session['results'] = "Draw"
    if session['comp_choice'] == 'nuke' and request.form['selected'] == 'cockroach':
        session['results'] = "you win!"
    if session['comp_choice'] == 'nuke' and request.form['selected'] == 'foot':
        session['results'] = "you lose!"
    if session['comp_choice'] == 'foot' and request.form['selected'] == 'nuke':
        session['results'] = "you win!"
    if session['comp_choice'] == 'foot' and request.form['selected'] == 'foot':
        session['results'] = "Draw"
    if session['comp_choice'] == 'foot' and request.form['selected'] == 'cockroach':
        session['results'] = "you lose!"
    if session['comp_choice'] == 'cockroach' and request.form['selected'] == 'cockroach':
        session['results'] = "Draw"
    if session['comp_choice'] == 'cockroach' and request.form['selected'] == 'nuke':
        session['results'] = "you lose!"
    if session['comp_choice'] == 'cockroach' and request.form['selected'] == 'foot':
        session['results'] = "you win!"
    return redirect('/')

@app.route('/reset')
def reset():
    session.clear()
    return redirect('/')


if __name__=="__main__":
    app.run(debug=True)